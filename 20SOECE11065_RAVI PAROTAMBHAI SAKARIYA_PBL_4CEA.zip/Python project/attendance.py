from asyncore import read
from base64 import decode
from tkinter import TRUE
from unicodedata import name
import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar
import sys
import time
import pybase64

cap = cv2.VideoCapture(0)
names = []

fob=open('attendanc.txt','+a')

def enterData(z):
    if z in names:
        pass
    else:
        names.append(z)
        z=join(str(z))
        fob.write(z+'\n')
        return names
print('reding code.......')


def checkData(data):
    data = str(data)
    if data in names:
        print("alredy present")
    else:
        print('\n'+str(len(names)+1)+'\n'+'present done')
        enterData(data)

while True:
frame = cap.read()
decodedobject = pyzbar.decode(frame)
for obj in decodedobject:
    checkData(obj.data)
    time.sleep(1)
cv2.imshow('frame',frame)
if cv2.waitKey(1)&oxff==ord('s'):
     cv2.destroyAllWindows()
     break
fob.close()
